﻿using System;

namespace Temat_23
{
	class Program
	{
		public static void Main(string[] args)
		{			
			char[,] mapa = {
				{ '#', '#', '#', '#', '#', '#', '#', '#', '#', '#' },
				{ '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', '#' },
				{ '#', ' ', '#', ' ', '#', ' ', '#', '#', '#', '#' },
				{ '#', ' ', ' ', ' ', '#', ' ', ' ', ' ', ' ', '#' },
				{ '#', '#', '#', '#', '#', '#', '#', '#', ' ', '#' },
				{ '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#' },
				{ '#', ' ', '#', '#', '#', '#', ' ', '#', '#', '#' },
				{ '#', ' ', '#', ' ', ' ', ' ', ' ', ' ', ' ', '#' },
				{ '#', ' ', '#', '#', '#', '#', '#', '#', '#', '#' },
				{ '#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '*', '#' },
				{ '#', '#', '#', '#', '#', '#', '#', '#', '#', '#' }
			};
			int pozycjaGraczaX = 1, pozycjaGraczaY = 1;
			bool koniec = false;
			while(!koniec)
			{
				Rysuj(mapa, pozycjaGraczaX, pozycjaGraczaY);
				koniec = CzyKoniec(mapa, pozycjaGraczaX, pozycjaGraczaY);
			}
		}
		
		static void Rysuj(char[,] mapa, int XGracza, int YGracza)
		{
			Console.SetCursorPosition(0, 0);
			RysujMape(mapa);
			RysujGracza(XGracza, YGracza);
		}

		static void RysujMape(char[,] mapa)
		{
			for(int x = 0; x < mapa.GetLength(1); x++)
			{
				for(int y = 0; y < mapa.GetLength(0); y++)
				{
					Console.SetCursorPosition(x, y);
					Console.Write(mapa[y, x]);
				}
			}
		}

		static void RysujGracza(int x, int y)
		{
			Console.SetCursorPosition(x, y);
			Console.Write('@');
		}
		
		static bool CzyKoniec(char[,] mapa, int x, int y)
		{
			return mapa[y, x] == '*';
		}

		
	}
}