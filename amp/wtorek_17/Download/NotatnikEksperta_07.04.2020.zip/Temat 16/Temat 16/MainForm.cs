﻿using System;
using System.IO;
using System.Windows.Forms;

//https://www.fileformat.info/info/unicode/char/search.htm

namespace Temat_16
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}
		void ZakończToolStripMenuItemClick(object sender, EventArgs e)
		{
			Close();
		}
		void OtwórzToolStripMenuItemClick(object sender, EventArgs e)
		{
			if(openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.UnicodePlainText);
			}
		}
		void ZapiszToolStripMenuItemClick(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog() == DialogResult.OK)
			{
				richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.UnicodePlainText);
			}
		}
		void NowyToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Clear();
		}
		void CofnijToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Undo();
		}
		void PonówToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Redo();
		}
		void WytnijToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Cut();
		}
		void KopiujToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Copy();
		}
		void WklejToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Paste();			
		}
		void RichTextBox1TextChanged(object sender, EventArgs e)
		{
			toolStripStatusLabel1.Text = "Liczba znaków: " + richTextBox1.Text.Length;
		}
		void EuroToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.SelectedText = "\x20AC";
		}
		void FuntToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.SelectedText = "\x00A3";
		}
		void UśmiechToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.SelectedText = "\x263A";
		}
		void WstawLinieToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.SelectedText = "\x000A";//Environment.NewLine;//"\n";
		}
		void ZamieńNaDużeToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Text = richTextBox1.Text.ToUpper();
		}
		void ZamieńNaMałeToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Text = richTextBox1.Text.ToLower();
		}
	}
}