﻿/*
 * Created by SharpDevelop.
 * User: pwoloszyn
 * Date: 2019/11/15
 * Time: 18:51
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Temat_16
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem nowyToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem otwórzToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem zapiszToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem zakończToolStripMenuItem;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.ToolStripMenuItem edycjaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem cofnijToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem ponówToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem wytnijToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem kopiujToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem wklejToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem narzędziaToolStripMenuItem;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.ToolStripMenuItem wstawToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem euroToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem uśmiechToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem funtToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem wstawLinieToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem literyToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem zamieńNaDużeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem zamieńNaMałeToolStripMenuItem;
		private System.Windows.Forms.ColorDialog colorDialog1;
		private System.Windows.Forms.FontDialog fontDialog1;
		private System.Windows.Forms.ToolStripButton toolStripButton1;
		private System.Windows.Forms.ToolStripButton toolStripButton2;
		private System.Windows.Forms.ToolStripButton toolStripButton3;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton toolStripButton4;
		private System.Windows.Forms.ToolStripButton toolStripButton5;
		private System.Windows.Forms.ToolStripButton toolStripButton6;
		private System.Windows.Forms.ToolStripButton toolStripButton7;
		private System.Windows.Forms.ToolStripButton toolStripButton8;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripButton toolStripButton9;
		private System.Windows.Forms.ToolStripButton toolStripButton10;
		private System.Windows.Forms.ToolStripButton toolStripButton11;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripButton toolStripButton12;
		private System.Windows.Forms.ToolStripButton toolStripButton13;
		private System.Windows.Forms.ToolStripButton toolStripButton14;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.plikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.nowyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.otwórzToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.zapiszToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.zakończToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.edycjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cofnijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ponówToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
			this.wytnijToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.kopiujToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.wklejToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.narzędziaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.wstawToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.euroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.funtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.uśmiechToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.wstawLinieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.literyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.zamieńNaDużeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.zamieńNaMałeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.colorDialog1 = new System.Windows.Forms.ColorDialog();
			this.fontDialog1 = new System.Windows.Forms.FontDialog();
			this.menuStrip1.SuspendLayout();
			this.toolStrip1.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.plikToolStripMenuItem,
			this.edycjaToolStripMenuItem,
			this.narzędziaToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(741, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// plikToolStripMenuItem
			// 
			this.plikToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.nowyToolStripMenuItem,
			this.otwórzToolStripMenuItem,
			this.zapiszToolStripMenuItem,
			this.toolStripMenuItem1,
			this.zakończToolStripMenuItem});
			this.plikToolStripMenuItem.Name = "plikToolStripMenuItem";
			this.plikToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
			this.plikToolStripMenuItem.Text = "Plik";
			// 
			// nowyToolStripMenuItem
			// 
			this.nowyToolStripMenuItem.Image = global::Temat_16.Resource1.New_document;
			this.nowyToolStripMenuItem.Name = "nowyToolStripMenuItem";
			this.nowyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
			this.nowyToolStripMenuItem.Size = new System.Drawing.Size(164, 26);
			this.nowyToolStripMenuItem.Text = "Nowy";
			this.nowyToolStripMenuItem.Click += new System.EventHandler(this.NowyToolStripMenuItemClick);
			// 
			// otwórzToolStripMenuItem
			// 
			this.otwórzToolStripMenuItem.Image = global::Temat_16.Resource1.Folder;
			this.otwórzToolStripMenuItem.Name = "otwórzToolStripMenuItem";
			this.otwórzToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
			this.otwórzToolStripMenuItem.Size = new System.Drawing.Size(164, 26);
			this.otwórzToolStripMenuItem.Text = "Otwórz";
			this.otwórzToolStripMenuItem.Click += new System.EventHandler(this.OtwórzToolStripMenuItemClick);
			// 
			// zapiszToolStripMenuItem
			// 
			this.zapiszToolStripMenuItem.Image = global::Temat_16.Resource1.Save;
			this.zapiszToolStripMenuItem.Name = "zapiszToolStripMenuItem";
			this.zapiszToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
			this.zapiszToolStripMenuItem.Size = new System.Drawing.Size(164, 26);
			this.zapiszToolStripMenuItem.Text = "Zapisz";
			this.zapiszToolStripMenuItem.Click += new System.EventHandler(this.ZapiszToolStripMenuItemClick);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(161, 6);
			// 
			// zakończToolStripMenuItem
			// 
			this.zakończToolStripMenuItem.Image = global::Temat_16.Resource1.Exit;
			this.zakończToolStripMenuItem.Name = "zakończToolStripMenuItem";
			this.zakończToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
			this.zakończToolStripMenuItem.Size = new System.Drawing.Size(164, 26);
			this.zakończToolStripMenuItem.Text = "Zakończ";
			this.zakończToolStripMenuItem.Click += new System.EventHandler(this.ZakończToolStripMenuItemClick);
			// 
			// edycjaToolStripMenuItem
			// 
			this.edycjaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.cofnijToolStripMenuItem,
			this.ponówToolStripMenuItem,
			this.toolStripMenuItem2,
			this.wytnijToolStripMenuItem,
			this.kopiujToolStripMenuItem,
			this.wklejToolStripMenuItem});
			this.edycjaToolStripMenuItem.Name = "edycjaToolStripMenuItem";
			this.edycjaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
			this.edycjaToolStripMenuItem.Text = "Edycja";
			// 
			// cofnijToolStripMenuItem
			// 
			this.cofnijToolStripMenuItem.Image = global::Temat_16.Resource1.Undo;
			this.cofnijToolStripMenuItem.Name = "cofnijToolStripMenuItem";
			this.cofnijToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
			this.cofnijToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.cofnijToolStripMenuItem.Text = "Cofnij";
			this.cofnijToolStripMenuItem.Click += new System.EventHandler(this.CofnijToolStripMenuItemClick);
			// 
			// ponówToolStripMenuItem
			// 
			this.ponówToolStripMenuItem.Image = global::Temat_16.Resource1.Redo;
			this.ponówToolStripMenuItem.Name = "ponówToolStripMenuItem";
			this.ponówToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
			this.ponówToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.ponówToolStripMenuItem.Text = "Ponów";
			this.ponówToolStripMenuItem.Click += new System.EventHandler(this.PonówToolStripMenuItemClick);
			// 
			// toolStripMenuItem2
			// 
			this.toolStripMenuItem2.Name = "toolStripMenuItem2";
			this.toolStripMenuItem2.Size = new System.Drawing.Size(149, 6);
			// 
			// wytnijToolStripMenuItem
			// 
			this.wytnijToolStripMenuItem.Image = global::Temat_16.Resource1.Cut;
			this.wytnijToolStripMenuItem.Name = "wytnijToolStripMenuItem";
			this.wytnijToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
			this.wytnijToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.wytnijToolStripMenuItem.Text = "Wytnij";
			this.wytnijToolStripMenuItem.Click += new System.EventHandler(this.WytnijToolStripMenuItemClick);
			// 
			// kopiujToolStripMenuItem
			// 
			this.kopiujToolStripMenuItem.Image = global::Temat_16.Resource1.Copy;
			this.kopiujToolStripMenuItem.Name = "kopiujToolStripMenuItem";
			this.kopiujToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
			this.kopiujToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.kopiujToolStripMenuItem.Text = "Kopiuj";
			this.kopiujToolStripMenuItem.Click += new System.EventHandler(this.KopiujToolStripMenuItemClick);
			// 
			// wklejToolStripMenuItem
			// 
			this.wklejToolStripMenuItem.Image = global::Temat_16.Resource1.Paste;
			this.wklejToolStripMenuItem.Name = "wklejToolStripMenuItem";
			this.wklejToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
			this.wklejToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.wklejToolStripMenuItem.Text = "Wklej";
			this.wklejToolStripMenuItem.Click += new System.EventHandler(this.WklejToolStripMenuItemClick);
			// 
			// narzędziaToolStripMenuItem
			// 
			this.narzędziaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.wstawToolStripMenuItem,
			this.wstawLinieToolStripMenuItem,
			this.literyToolStripMenuItem});
			this.narzędziaToolStripMenuItem.Name = "narzędziaToolStripMenuItem";
			this.narzędziaToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
			this.narzędziaToolStripMenuItem.Text = "Narzędzia";
			// 
			// wstawToolStripMenuItem
			// 
			this.wstawToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.euroToolStripMenuItem,
			this.funtToolStripMenuItem,
			this.uśmiechToolStripMenuItem});
			this.wstawToolStripMenuItem.Name = "wstawToolStripMenuItem";
			this.wstawToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
			this.wstawToolStripMenuItem.Text = "Wstaw";
			// 
			// euroToolStripMenuItem
			// 
			this.euroToolStripMenuItem.Image = global::Temat_16.Resource1.Euro;
			this.euroToolStripMenuItem.Name = "euroToolStripMenuItem";
			this.euroToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
			this.euroToolStripMenuItem.Text = "Euro";
			this.euroToolStripMenuItem.Click += new System.EventHandler(this.EuroToolStripMenuItemClick);
			// 
			// funtToolStripMenuItem
			// 
			this.funtToolStripMenuItem.Image = global::Temat_16.Resource1.pound;
			this.funtToolStripMenuItem.Name = "funtToolStripMenuItem";
			this.funtToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
			this.funtToolStripMenuItem.Text = "Funt";
			this.funtToolStripMenuItem.Click += new System.EventHandler(this.FuntToolStripMenuItemClick);
			// 
			// uśmiechToolStripMenuItem
			// 
			this.uśmiechToolStripMenuItem.Image = global::Temat_16.Resource1.Smile;
			this.uśmiechToolStripMenuItem.Name = "uśmiechToolStripMenuItem";
			this.uśmiechToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
			this.uśmiechToolStripMenuItem.Text = "Uśmiech";
			this.uśmiechToolStripMenuItem.Click += new System.EventHandler(this.UśmiechToolStripMenuItemClick);
			// 
			// wstawLinieToolStripMenuItem
			// 
			this.wstawLinieToolStripMenuItem.Image = global::Temat_16.Resource1.Next;
			this.wstawLinieToolStripMenuItem.Name = "wstawLinieToolStripMenuItem";
			this.wstawLinieToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
			this.wstawLinieToolStripMenuItem.Text = "Wstaw linie";
			this.wstawLinieToolStripMenuItem.Click += new System.EventHandler(this.WstawLinieToolStripMenuItemClick);
			// 
			// literyToolStripMenuItem
			// 
			this.literyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.zamieńNaDużeToolStripMenuItem,
			this.zamieńNaMałeToolStripMenuItem});
			this.literyToolStripMenuItem.Name = "literyToolStripMenuItem";
			this.literyToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
			this.literyToolStripMenuItem.Text = "Litery";
			// 
			// zamieńNaDużeToolStripMenuItem
			// 
			this.zamieńNaDużeToolStripMenuItem.Image = global::Temat_16.Resource1.Up;
			this.zamieńNaDużeToolStripMenuItem.Name = "zamieńNaDużeToolStripMenuItem";
			this.zamieńNaDużeToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
			this.zamieńNaDużeToolStripMenuItem.Text = "Zamień na duże";
			this.zamieńNaDużeToolStripMenuItem.Click += new System.EventHandler(this.ZamieńNaDużeToolStripMenuItemClick);
			// 
			// zamieńNaMałeToolStripMenuItem
			// 
			this.zamieńNaMałeToolStripMenuItem.Image = global::Temat_16.Resource1.Down;
			this.zamieńNaMałeToolStripMenuItem.Name = "zamieńNaMałeToolStripMenuItem";
			this.zamieńNaMałeToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
			this.zamieńNaMałeToolStripMenuItem.Text = "Zamień na małe";
			this.zamieńNaMałeToolStripMenuItem.Click += new System.EventHandler(this.ZamieńNaMałeToolStripMenuItemClick);
			// 
			// toolStrip1
			// 
			this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.toolStripButton1,
			this.toolStripButton2,
			this.toolStripButton3,
			this.toolStripSeparator1,
			this.toolStripButton4,
			this.toolStripButton5,
			this.toolStripButton6,
			this.toolStripButton7,
			this.toolStripButton8,
			this.toolStripSeparator2,
			this.toolStripButton9,
			this.toolStripButton10,
			this.toolStripButton11,
			this.toolStripSeparator3,
			this.toolStripButton12,
			this.toolStripButton13,
			this.toolStripButton14});
			this.toolStrip1.Location = new System.Drawing.Point(0, 24);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(741, 27);
			this.toolStrip1.TabIndex = 1;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// toolStripButton1
			// 
			this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton1.Image = global::Temat_16.Resource1.New_document;
			this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton1.Name = "toolStripButton1";
			this.toolStripButton1.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton1.Text = "Nowy";
			this.toolStripButton1.Click += new System.EventHandler(this.NowyToolStripMenuItemClick);
			// 
			// toolStripButton2
			// 
			this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton2.Image = global::Temat_16.Resource1.Folder;
			this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton2.Name = "toolStripButton2";
			this.toolStripButton2.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton2.Text = "Otwórz";
			this.toolStripButton2.Click += new System.EventHandler(this.OtwórzToolStripMenuItemClick);
			// 
			// toolStripButton3
			// 
			this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton3.Image = global::Temat_16.Resource1.Save;
			this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton3.Name = "toolStripButton3";
			this.toolStripButton3.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton3.Text = "Zapisz";
			this.toolStripButton3.Click += new System.EventHandler(this.ZapiszToolStripMenuItemClick);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
			// 
			// toolStripButton4
			// 
			this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton4.Image = global::Temat_16.Resource1.Undo;
			this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton4.Name = "toolStripButton4";
			this.toolStripButton4.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton4.Text = "Cofnij";
			this.toolStripButton4.Click += new System.EventHandler(this.CofnijToolStripMenuItemClick);
			// 
			// toolStripButton5
			// 
			this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton5.Image = global::Temat_16.Resource1.Redo;
			this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton5.Name = "toolStripButton5";
			this.toolStripButton5.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton5.Text = "Ponów";
			this.toolStripButton5.Click += new System.EventHandler(this.PonówToolStripMenuItemClick);
			// 
			// toolStripButton6
			// 
			this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton6.Image = global::Temat_16.Resource1.Cut;
			this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton6.Name = "toolStripButton6";
			this.toolStripButton6.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton6.Text = "Wytnij";
			this.toolStripButton6.Click += new System.EventHandler(this.WytnijToolStripMenuItemClick);
			// 
			// toolStripButton7
			// 
			this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton7.Image = global::Temat_16.Resource1.Copy;
			this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton7.Name = "toolStripButton7";
			this.toolStripButton7.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton7.Text = "Kopiuj";
			this.toolStripButton7.Click += new System.EventHandler(this.KopiujToolStripMenuItemClick);
			// 
			// toolStripButton8
			// 
			this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton8.Image = global::Temat_16.Resource1.Paste;
			this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton8.Name = "toolStripButton8";
			this.toolStripButton8.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton8.Text = "Wklej";
			this.toolStripButton8.Click += new System.EventHandler(this.WklejToolStripMenuItemClick);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
			// 
			// toolStripButton9
			// 
			this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton9.Image = global::Temat_16.Resource1.Euro;
			this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton9.Name = "toolStripButton9";
			this.toolStripButton9.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton9.Text = "Euro";
			this.toolStripButton9.Click += new System.EventHandler(this.EuroToolStripMenuItemClick);
			// 
			// toolStripButton10
			// 
			this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton10.Image = global::Temat_16.Resource1.pound;
			this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton10.Name = "toolStripButton10";
			this.toolStripButton10.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton10.Text = "Funt";
			this.toolStripButton10.Click += new System.EventHandler(this.FuntToolStripMenuItemClick);
			// 
			// toolStripButton11
			// 
			this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton11.Image = global::Temat_16.Resource1.Smile;
			this.toolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton11.Name = "toolStripButton11";
			this.toolStripButton11.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton11.Text = "Uśmiech";
			this.toolStripButton11.Click += new System.EventHandler(this.UśmiechToolStripMenuItemClick);
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
			// 
			// toolStripButton12
			// 
			this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton12.Image = global::Temat_16.Resource1.Next;
			this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton12.Name = "toolStripButton12";
			this.toolStripButton12.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton12.Text = "Wstaw linię";
			this.toolStripButton12.Click += new System.EventHandler(this.WstawLinieToolStripMenuItemClick);
			// 
			// toolStripButton13
			// 
			this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton13.Image = global::Temat_16.Resource1.Up;
			this.toolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton13.Name = "toolStripButton13";
			this.toolStripButton13.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton13.Text = "Duże litery";
			this.toolStripButton13.Click += new System.EventHandler(this.ZamieńNaDużeToolStripMenuItemClick);
			// 
			// toolStripButton14
			// 
			this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton14.Image = global::Temat_16.Resource1.Down;
			this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton14.Name = "toolStripButton14";
			this.toolStripButton14.Size = new System.Drawing.Size(24, 24);
			this.toolStripButton14.Text = "Małe litery";
			this.toolStripButton14.Click += new System.EventHandler(this.ZamieńNaMałeToolStripMenuItemClick);
			// 
			// statusStrip1
			// 
			this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.toolStripStatusLabel1});
			this.statusStrip1.Location = new System.Drawing.Point(0, 520);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(741, 22);
			this.statusStrip1.TabIndex = 2;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(95, 17);
			this.toolStripStatusLabel1.Text = "Liczba znaków: 0";
			// 
			// richTextBox1
			// 
			this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBox1.Location = new System.Drawing.Point(0, 51);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(741, 469);
			this.richTextBox1.TabIndex = 3;
			this.richTextBox1.Text = "";
			this.richTextBox1.TextChanged += new System.EventHandler(this.RichTextBox1TextChanged);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.DefaultExt = "txt";
			this.openFileDialog1.Filter = "Pliki tekstowe|*.txt|Wszystkie Pliki|*.*";
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.DefaultExt = "txt";
			this.saveFileDialog1.Filter = "Pliki tekstowe|*.txt|Wszystkie Pliki|*.*";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(741, 542);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.toolStrip1);
			this.Controls.Add(this.menuStrip1);
			this.Icon = global::Temat_16.Resource1.ikonaAplikacji;
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "MainForm";
			this.Text = "Notatnik Eksperta";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
