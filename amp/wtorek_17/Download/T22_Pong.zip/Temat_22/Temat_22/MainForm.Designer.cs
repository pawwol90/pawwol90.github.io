﻿/*
 * Created by SharpDevelop.
 * User: pwoloszyn
 * Date: 2020/02/22
 * Time: 09:43
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Temat_22
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Panel gL;
		private System.Windows.Forms.Panel gP;
		private System.Windows.Forms.PictureBox pilka;
		private System.Windows.Forms.Timer gra;
		private System.Windows.Forms.Panel background;
		private System.Windows.Forms.Label talicaWynikow;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.gL = new System.Windows.Forms.Panel();
			this.gP = new System.Windows.Forms.Panel();
			this.pilka = new System.Windows.Forms.PictureBox();
			this.gra = new System.Windows.Forms.Timer(this.components);
			this.background = new System.Windows.Forms.Panel();
			this.talicaWynikow = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pilka)).BeginInit();
			this.background.SuspendLayout();
			this.SuspendLayout();
			// 
			// gL
			// 
			this.gL.BackColor = System.Drawing.Color.Black;
			this.gL.Location = new System.Drawing.Point(0, 0);
			this.gL.Name = "gL";
			this.gL.Size = new System.Drawing.Size(15, 100);
			this.gL.TabIndex = 0;
			// 
			// gP
			// 
			this.gP.BackColor = System.Drawing.Color.Black;
			this.gP.Location = new System.Drawing.Point(765, 460);
			this.gP.Name = "gP";
			this.gP.Size = new System.Drawing.Size(15, 100);
			this.gP.TabIndex = 1;
			// 
			// pilka
			// 
			this.pilka.BackColor = System.Drawing.Color.Transparent;
			this.pilka.Image = global::Temat_22.Resource1.pilka;
			this.pilka.Location = new System.Drawing.Point(385, 285);
			this.pilka.Name = "pilka";
			this.pilka.Size = new System.Drawing.Size(30, 30);
			this.pilka.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pilka.TabIndex = 2;
			this.pilka.TabStop = false;
			// 
			// gra
			// 
			this.gra.Interval = 40;
			// 
			// background
			// 
			this.background.Controls.Add(this.talicaWynikow);
			this.background.Dock = System.Windows.Forms.DockStyle.Fill;
			this.background.Location = new System.Drawing.Point(0, 0);
			this.background.Name = "background";
			this.background.Size = new System.Drawing.Size(784, 561);
			this.background.TabIndex = 3;
			// 
			// talicaWynikow
			// 
			this.talicaWynikow.BackColor = System.Drawing.Color.Transparent;
			this.talicaWynikow.Dock = System.Windows.Forms.DockStyle.Top;
			this.talicaWynikow.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.talicaWynikow.Location = new System.Drawing.Point(0, 0);
			this.talicaWynikow.Name = "talicaWynikow";
			this.talicaWynikow.Size = new System.Drawing.Size(784, 33);
			this.talicaWynikow.TabIndex = 0;
			this.talicaWynikow.Text = "0 : 0";
			this.talicaWynikow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MainForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(784, 561);
			this.Controls.Add(this.gP);
			this.Controls.Add(this.gL);
			this.Controls.Add(this.pilka);
			this.Controls.Add(this.background);
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(800, 600);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(800, 600);
			this.Name = "MainForm";
			this.ShowIcon = false;
			this.Text = "Pong";
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainFormKeyUp);
			((System.ComponentModel.ISupportInitialize)(this.pilka)).EndInit();
			this.background.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
