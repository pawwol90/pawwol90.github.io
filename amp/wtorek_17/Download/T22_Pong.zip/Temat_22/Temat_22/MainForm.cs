﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Temat_22
{
	public partial class MainForm : Form
	{
		enum KierunekPilki 
		{
			GoraPrawo,
			DolPrawo,
			GoraLewo,
			DolLewo
		}
		
		int predkoscL = 15;
		int predkoscP = 15;		
		KierunekPilki AktualnyKierunekPilki;
		
		public MainForm()
		{
			InitializeComponent();
		}
		
		void MainFormLoad(object sender, EventArgs e)
		{
			ResetPilki();
			ResetGraczy();
		}	
		
		void MainFormKeyUp(object sender, KeyEventArgs e)
		{
			switch (e.KeyCode) 
			{
				case Keys.Z: //Gracz po prawej w dół
					gL.Location = new Point(gL.Location.X, gL.Location.Y + predkoscL);
					if(gL.Location.Y + gL.Size.Height > background.Size.Height)
					{
						gL.Location = new Point(gL.Location.X, background.Size.Height - gL.Size.Height);
					}
					break;
				case Keys.A: //Gracz po prawej do góry
					gL.Location = new Point(gL.Location.X, gL.Location.Y - predkoscL);
					if(gL.Location.Y < 0)
					{
						gL.Location = new Point(gL.Location.X, 0);
					}
					break;
				case Keys.Down: //Gracz po lewej w dół
					gP.Location = new Point(gP.Location.X, gP.Location.Y + predkoscP);
					if(gP.Location.Y + gP.Size.Height > background.Size.Height)
					{
						gP.Location = new Point(gP.Location.X, background.Size.Height - gP.Size.Height);
					}
					break;
				case Keys.Up: //Gracz po lewej do góry
					gP.Location = new Point(gP.Location.X, gP.Location.Y - predkoscP);
					if(gP.Location.Y < 0)
					{
						gP.Location = new Point(gP.Location.X, 0);
					}
					break;
				case Keys.Space: //Start gry
					if (!gra.Enabled) 
					{
						gra.Start();
					}
					break;
			}
		}
		

		void ResetPilki()
		{
			int x = (background.Size.Width / 2) - (pilka.Size.Width / 2);
			int y = (background.Size.Height / 2) - (pilka.Size.Height / 2);
			pilka.Location = new Point(x, y);
			Random rnd = new Random();
			AktualnyKierunekPilki = (KierunekPilki)rnd.Next(0, 4);
		}

		void ResetGraczy()
		{
			gL.Location = new Point(0, (background.Size.Height / 2) - (gL.Size.Height / 2));
			gP.Location = new Point(background.Size.Width - gP.Size.Width, (background.Size.Height / 2) - (gP.Size.Height / 2));
		}
		
		
	}
}
