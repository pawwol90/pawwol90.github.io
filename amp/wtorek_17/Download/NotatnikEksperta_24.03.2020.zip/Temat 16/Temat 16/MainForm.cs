﻿using System;
using System.IO;
using System.Windows.Forms;

//https://www.fileformat.info/info/unicode/char/search.htm

namespace Temat_16
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}
		void ZakończToolStripMenuItemClick(object sender, EventArgs e)
		{
			Close();
		}
		void OtwórzToolStripMenuItemClick(object sender, EventArgs e)
		{
			if(openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.UnicodePlainText);
			}
		}
		void ZapiszToolStripMenuItemClick(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog() == DialogResult.OK)
			{
				richTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.UnicodePlainText);
			}
		}
		void NowyToolStripMenuItemClick(object sender, EventArgs e)
		{
			richTextBox1.Clear();
		}
	}
}